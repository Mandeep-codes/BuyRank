#!/usr/bin/env bash
#
# One command from "unzipped" to "live":
#
#   ./ship.sh          # install deps, migrate DB, build check, deploy to prod
#   ./ship.sh dev      # same setup, but start the local dev server instead
#
# Needs: .env.local with DATABASE_URL (already present), and the Vercel CLI
# logged in for deploys (`npx vercel login` once, if you never have).

set -euo pipefail
cd "$(dirname "$0")"

echo "==> Installing dependencies"
npm ci

echo "==> Pushing schema (adds click_events + sponsor_slots)"
npm run db:push -- --force

if [ "${1:-}" = "dev" ]; then
  echo "==> Starting dev server"
  exec npm run dev
fi

echo "==> Production build check"
npm run build

echo "==> Deploying to Vercel (production)"
npx vercel --prod

echo ""
echo "Done. The homepage now has the sponsored card, live traffic, and rent-a-spot rails."
echo "Reminder: the sponsor rental reuses your existing Dodo PWYW product — no dashboard changes needed."

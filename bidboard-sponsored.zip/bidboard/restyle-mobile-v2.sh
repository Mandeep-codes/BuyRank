#!/bin/sh
# BuyRank — restyle to match the outbid.lol reference.
set -eu
[ -f package.json ] || { printf 'Run from inside your project folder.\n'; exit 1; }
grep -qx '.backup-\*' .gitignore 2>/dev/null || printf '.backup-*\n*.sh\n' >> .gitignore
STAMP=$(date +%Y%m%d-%H%M%S); mkdir -p ".backup-$STAMP"
cp -R src tailwind.config.ts ".backup-$STAMP"/ 2>/dev/null || true
printf 'Backed up to .backup-%s\n\n' "$STAMP"
if printf 'aGk=' | base64 -d >/dev/null 2>&1; then D="-d"; else D="-D"; fi
base64 $D <<'B64' | tar xzf -
H4sIAAAAAAAAA+xc63LbRpbObz1FB+PKkA4JXnRxTEvyKI4y4xnHclnyzE6pvE4TaIqIQDTSDYhiFFbNz/29tc+wD5Yn2XNON4AGSEp24jg1WbPKFgH05fS5
fqf7gFoFvU9+5U8fPg92d+kvfJp/6ftgd7gzfLCzt7374JP+oL+9N/yE7f7ahOEn1xlXjH2ipMxua3fX83/Tjwb5B3KWykQkmf51VOHd5T/c3XnwUf4f4tOQ
/5OYR7MXPBGxn+nr9zQHCnhvZ2eD/AcPhrvDhvx3t4fbn7D+e5r/1s//c/l7uRYsiCOQvvdoaysCTVAZu2Fw+3gyEUHWwa+nGc8EW7KJkjPmKcEDbF02fnJ0
dvznk5dPj0/LNn/qxdEYNCuZRBdu04lUM5690mGjpbmPJGSLVLAXSlxFYs4O2M0WY7mKR0xnKkouHsFlGOk05ovnfCbc2zL5UnIVjthYyljwBO8FuVKwtC+j
8Anq94gl+WwsFD6aRUk0y2eN+0ugoHf//ha7z/4ilGQ8Cdk4ColuNhPqQoQsSjIJswmWkqFAW2x+NoUbKgoE01GmoZGOQsEyuDsVPIwjaD+Psin76b/+u/c5
kC3SVCjNFIcmCtrxBPowjkNpkXKFHA9gPYyP5ZVgvLrLZzJPMjaJRBz67AQ6sXSK9MAgGctylWjmhSKA+XG0Od2VuAzP0J7N4R9PicgMiGNyAgsMcg2chMEM
L+BhmmfEABAJPOngYHgZZUyJGRClofF8CsxmOlBCJDjOVEQX04z99K//gUdRMGUg1gwXOhYBR2WbSZ1hw2waaRwxU3wyiQLGlYpwSNIKzoBhl8QQpmUQ8Zjx
NEVW97bENenSJE+CLJIJq3xWC5WFZPC1VF9HSmdAMxMJH8ci7GwtR2ylgasRtqGjQMs29QA1BprPdT6eRVrDnB0QRnZaXr4GPS2spOV57UdVnwBuXUi1oB5P
7EW9vUQFqHUyAibNpH5H1XWta20l7gBixqOYuh7jt1voS42hUVtrdG7r/cIQfwQ+xfFhC/+vzaSUVGYm/Fbra0xzY9dUJCGqFU1tvtcInfBYC+gAPXo95mX8
UqDqgSWye//hkYJYbUEjG6Ptsxj1E9hpbQ1syvDSRy9SuLRWq80ODkmyBTFznmRg2QcsgbW+evnsVHAVTF+Avc10ax4loZz7sQRhgrR9TQ/b/oXIWp4Z3/C0
GC2UccxB5Q/YN2Dd/iSWUrWek561zExt2z6asFbR+pD12w1pl8/us0G/T32WHXb+uuTKS6FlfGXcDFkM1/h9wciLamkutBDWC8DVH4E54L9zHscL6KMz4Ptd
7LnicS5gOZUF+CDbWctZBTXxY5FcAN/32U7bDsAczapUAD9KoKsyV0tnsiwCP4uTiewMvso8a3G9SALm0sXAbyzK70VXJZDpfM5RT0QWTFtej6dRbyYyHvKM
ex2nC4QAkU0l2Lv34uT0zOs4T9Blg9MCh8G8JxIklmTdM2CpB43BEcWRUYXed1omHsjE6TqW4WLE/np68tw3BhBNFq0bh3Ujy85lu+q2LLlS4xesx5eX7DFr
tcyi8AbO2Wq3UdS2XZuNWI21S4gcsHpnsZuEYBgPSrWz27c3jVwstwNwhKoQA0mm1MJqRVYfjQxsXAU5WN/y2LeRGdZhb/lu8AXiQbkrxzAWsZx/U47iOEPQ
K9uR5isjAAbTVijijNeieaGCDZtqBbQyMs0Zv27ZITssYJ+zahRjoksytPv32T/QfhQHE8PARZhgnC/AP0OMAjQC/8+lCrWPEapYCUBLcmuwippRob24q2wX
PEfRVCblrvzwoB63yi7eGZKDzpEsHwJ9ynQqM9+rSdN7BqRo8ALgG68Ib0AvCyQQz02hO3Cy9KSm+7LdMqI1BlgyHMBKGAsKgFkLxksgjr5EVOgDfbNjvFEw
n576KHf4+5WY8DzOCr9RRA1XJatg0MpULuxd19hvN3VYSXAJyloz9U2G/rPNfL2RO17AwQrO3RINuP4iCr8yXn7khgtX+D3y/m4nCvAj84f9+CPLk1BMAGKG
rkspvlfOxYYn8ISokmtdyg0rOPhKxY9LfM0o0JfXbFkMiYr6qfVTQMinOLjvDNGuOyEjb2pEI7LHj5H1eRwmfwRYCJignN9nZyB1fgG25XsN/2g1pIAIxSM3
pBS+jbFm/J4qMYH1Nym1kajhOkuavecCcLO6NJzw2RPsyRYyV8jWRBjLILi8huwNRC9LF9NjOzvpNZhvDpNDSgrgQj9iPoF8BvAboA4oaFdHP6CNs8EeNIb4
Hp2cAtwQGrn3g5Qz33E+lGHAQj38yqbdwYDN8T89BRFedvssE9dZd3gd26HFLBrLOPTI4osoQGTua7u8KDzwKI8IYq41ZmAHHmB/0N/uLOvumBEDUFpAtId2
6fthdOW2n8TimuF/3bniKUA6MdO2D/sO0nEwpeLygqfdaxgW/y662+WQMOh04I5J857DjVnaGvgPIT3p7Pm7V/POtr8DF+3XZonQSnFcI4OwhsLoJpQ3KR5c
4lWGuYszCzPJBfvDAGFnNXlvOnBIWbe+2qqQ/O3asPvjPMtk4txhBNmAu/TAqz2RyRNwRZcHNyaIULjroktY1ppBXkwJzMFNLWYeFEGz3rqi+MaqSv05VxHv
xhzi1IH3TM4pZggT9xaU/Rps6lJ6WBvgM5g214/cVffM6g633Jsa0uiaLCF6M1egQ3+IAn3488Rphkpl6tXJuym3IlxfW2Ppfg9pq1P7iwW3Krd3kcRLHmnx
rpL4fK0MqjugwKWxmoviKnUFM7vu8hx8D1j6HqT1YL9d8B1GUuiPXpdiUCLm15BP0bNZngnXcpvyrjkfR1rPIRWz+YlGKAU5P0CwewPfiuXGY17FqC+jkKBW
LLQ2uykFGrKbMlkUxyzNwSLAZ9ewTgfHxfwIkVE5IIC6wG6pWJwU4KAAtPySV2nFKdogkonBRAc3LkJabmDiF5aJ2wUXYzFxvU/TsVwoEDn6kqG/y/RshNfd
QMYa2D9Rb8DcEM72OwM0l/YbnOZ13euQErlDjiEoXjYMY0VAWnVlEi+8wxdKhnmQYYLMIHT/ySyysJLaGLR5VLvFTNoDOl5Co2WjAZgLDHkBbVrCGIy7y9IS
vomLPg3UbvYmgU1Bh4Q68P6JcTldS6/X6Id8eiJnaSwyWGyu4rUNAFtmPIboe+Chk2m20amIY4IEBzcU4JvUKfF9HikRNm67doChvj5urya9Homv7o5+oUSL
Ham1MtQihrC/XogFkn0bERaT3CXA23lx2Gh9U+06QxqXFmldq9EM1iFTwi6XYgF0+zrOL5blMsxlc2waP/CJuU0qURBmxGavdmNFwFTi4J1C3BhTyFSyOh+q
KP+p3bBE3G030/BrLX9GSL7J4Bx+p+gc590J5GFsfIH+l6XX3YcsXXTP+/7DXXAor2uenpy247A5Qk0IvImOTIYowZeOYKjzP4QPd3eGk9cl4aMgV1oqiNVZ
l8dAK6ygfGYm13KSVfeKkNDb7aPbm5MD3RztKr5AanEqMXMblfyBWz/963/xjneSZwhl6wF/Q3CsrlcMDhw5+uNVu9tsdbQpSxuZGIOUCESUZqsmuMaJWrWl
vK8uzHWGR/PcbnVGz2i8uprVvGlFMOU7lmLWMnbA43a9b92jrhn8bo/a9AWoidtuk54ro6ZNNXALZiYQHbvT7jlgSUeZLT63ir3jQhid5Bdr8UtdweruxitQ
CCayGtNpLTEp1CzlixlMhlLJIeeBbA4MVE9F6LuLwo08mxY3Rl5FySVOuqEey1X9wdFqzuAdBm062+Ze3opTfMy+PUOsRLvQqDea3XMgdrHx1ziQay99RG4I
wIDxkLW6fWza0l5iwovnTbj9n6f+tyuTj3AbTJRbjwiNgcUAFb0Vj7yGR2v2KRt8arJjPeNg5SCNYqXOKWUhGySKxwo0bNEYEHGuIDa8Nc9Iz2iboYk0MEXQ
wCu/sfbmuu9Y5E2xfblkR4ZoS+ZjdmzMBliuYXmEr0BENLHxECCBW2dfOsabVrkHrt1cYewMiiDbfrS13PqtT8p/n59G/cc3YIO4Kfoeqz/uqv/ob+/2V+o/
4ObH+o8P8bGFGc/Qa5t6jARcWQ+9uFu2cfr07PjN86Nvjn95gYdtSQeUN4wcLp736kb773OhIqHdoZ9FV+IJZeJFU79X3sNdy2ZlQKHNePxmpsCdfvo6qs1s
NqnrW57mbGDTJmaRxtNmn0njdyGNX7uZORbZHKsjMHXfQVy9g2iGUni42HMzfpID7k8feD3v7k1FAJ63Q046sJp2vwBs/0UBc3YB5jT3wkr5+sGUq6Os1W/7
mXyFe1FPuBattdtit8xrp3pYpgrVVt0tm60uIbdNuN9DPrl4L+FvsQW763LAkDUTYVTsNiLOo20VaPqgzlZXLCqPQS1ri22mPRUaqC3uJfasLcssY8NEwK48
+1kTHWHPWyba7wG/1u/43fTus5NEsO/zSGQM08IOQxYqQCdY02MSlokAQBIIs52G1U4xmKE9ddVUf4HnoMsNtoMW4Cr92k1GEiFkpAD5jHlRbvouxwZDe2ww
YEri+VhYprdzrqelHQ7XpQLbt2oIXehZU0cK79RbNQ3awp0CaBPJ4Wcz+CuzRxvM6I6tG9odX7NluqoFtS1ucnpg0pBxre5zlxZW31LFT8oBS2sQB1dv4QF+
o2WaxRV7xW+5MoNlb/UyacNGzNcqMPwOcGkD/5VK/D4B4B34b2dvbwX/DYcPPuK/D/H5JfW/W+ag+fTs5OXRn4/f/O34n3jYPM4XiDreXEUQqqSCdqbZX46P
Xp59eXx09uabU2j3sP+mj1U/WG3LXkKiKWcdxhOZLGYy1x12IRKB1a5YbmuOapSca6F89lxmDAwQNDW0xaLJIptiFRvW3pTgz85/Ji9F0mqXhQtVPecMCwoP
2Gq123iRUXFJoBZpJrHMz9D3d9w/0y0qEYyS7IsjpfiiNdhr1wun6LaPlLVopA5rjWmOMfjfU6ICO/kpR/ipstaww7y+127738koKeozqcCiKnsxlIlr4+OA
OKxmiE9hgfxCIIlPIR62HFE4pXllr88+Y73/PO93H/Lu5PXN9nB5r+cDgVnZol2WFRV33LLGDFkJUyPjihKeGhl6lYyO6VXnEN2iRdaKLXo99gLEiqpGwkaS
qYxTm/HLHWFCIuZAL0Bn1SEAwEKJVRBYVQ20++6EFcVL8NgreULp9Vq1el8a21Tg0tNa8e3+DZMJVnWXFcSMomtxCWsrCl+JEvzaMTFj6/ZiywjrUOvaa3kt
6AwyEHFMtap0zvTIILdGgdZY8GIx+HmXWskUHiC4+w1rJYEDy3a9biqYAqO9RHZRF4S3vnLSqUVqN2qB3rL26Q6RNqYqhdGudIRqm24pxAQlP5lM6HUAqcyp
gQh99kzwoowXt0EvEzlPSkDNYwjPxX6ardg0YjdyrhlpVT37FBHtFY9b2KpTc8C1LjL5O2gbGFbDGxblyUGOW9c+quQ4iqNsYcLBwQF4+yvT02vXSLGMKrvy
MKSiwGeIucCvt7xqsICOLUDbSjLaVqdrhahl9Z9jAFggWJa2YaFqueKqUrVGh3lt4d1IKdfTrLyGlEKxRFLoYSD6KCb5TbA8EzULMJUWHVuETakUS6j2cgIi
ntLLEz8IJVGuRptIfxq1oCvbEiUkXSmjWJvzDmo7BCudxma7HpthbRj838yVZhDpPBfY105e3ha20yi1MxSzWt8YHATGZxhIhA2Pnki6r0699tIapIPJXYze
uHrLFKSRfvzs1KNYAvmIjStokl5PRKyb1wyCXYC2Dw58umZ1Zvv8V8g3Gvj/CMLHFVm4itL3lQPcif/7ew38vzfY/vj+3wf53IL/TwFRHF+DI0kMwrvlBcBy
n6FD8efoQt7+eh+iRPtuXxS+xat9ToGe+8JWAIRAhnCUuW1xs2rx1BnVvtJH21qpBK+mpxy3s3igpNZYoA7oaGZwJJWZCSqsq3y5zsc6UNEYkw/IMEzQfHHy
7JnJZIZFJoP4TCc81VMJFOEazxExnr8uUqDYxhxtXzQ6Fdm+iW5XMgoPMXriGBS8sKAe/T4iqX1kmpy4Mf3QoksciQIFdoySr2MqeaywYQMX4votLsSYU3Rw
0ZIzSBFfm2nIJujIrffwnORjLR57KyxGsazk47Ia0iRYkTb5F5VxU9u2886RFUNR5k3PCzhQisEHtTwGaNlqxSQFYI1bl91MTo5YqGSagnqQGkVUdD0HC4AM
JVcTHlChPOoNnqFQZSaNANzK8d1FtIkoofeu7HsgK/KyCUr1Zkuheq2C6BGrNMast1oOwKyyHS0EuVU9ptpxRG2D9lqYiKvqFIpN/dcgsGq4UGB9R33CjVP2
Mfk0qKyCcrdAtoK+6o2YpUmK16RvtaCF6UMSZfjGKJ322ItKj9wUj9TCJnVNb2fwVikAk3EYTrQK9SredzuE9T2ulG5UzNp2e9l7VRJYB3Yc3xcuMcp0uOY4
ZbteeZXj8UzAtVPxfN73B2V1S6Nw5aVAXIhH88UhxH5vOqx2/okZxYqMzNxCiDU1NXYffEOZzHMLjRcCX+UovSkWZwCX5mgU5qhg3Y5rvT5hP2+WXO0wAEeB
6C66wzooM6vQkHWKVr/DHrRNcSDeXlMfuB9Hpi4Qn/tRWCvVpbevN1Tz4/HBNsBlPEBoHMLRuE1QieVH827fHGAMVtqvheaQGqILTrDWslajVAenRcXSuvM0
hym1gpTV6dcUgN5GlqFmiNSsl345twUEJAG/jNgrxZ+bSNhwdy1or7/Y4p7zNUrLV+Z2TkqIzk1vBGyiaB9QTq3ApQb887hU66WF86W1/8ZnCM3f/7Clui8g
W9UfCP8Ph4NBE/9D+4/4/0N83rL+4+5f+Ch/NUOq6AcwOYi/5sWw2i9c4NEt/pYE7eAOt4sXIiOASPSo+HWNicwVjobbwPiuRvELF/h6XZpj3aTz0r+cTEwt
Gv0IxYYfiXAVGzACQVVhIIL57rzbuK4cJOFX1obd13GelPQXZZyOT+rO8IiZAghCg+61qdlgeHQ/ieW8a4+6zUn0uDtg54ZlY6668yjMpiMsjH2NR84wVN8W
jPTZ+WejUXcuxpcRhIGix+uR2fUwhJRAAhdcVZRYso/i2LPLPrj51HxZVhs7d5bW06iOu3NL692dYZz25tte8bJA717R6Fu3mSFqXb19QaKVFoKS5iwl0e3S
t9riBvKsFZRGkukVXaQKQRjNhl/M6OXvg+BzN6GkdrVstNCX5u+E1DUGbWrLZQT+v1xRk5tvy7BFWmLedJpPIQ4ZiJNIKniobcw1ihdcaFhtWlXVIveq/WdD
vMPjx8yzFf9VJb9bkzyi51QyURVBlOX9RbG+U4+CEbbYq7ZyLhXLkXBVlPI7OEb/t/004v8plqcDcAf0/P4qAO6I/3t7g5Xz/93dvY/x/0N8bo//RVD/imd8
jIlmquQ4xpx5Luh1yAQ8mM+O7AE8EzG0iTQ6wqnCEywM8xCWzO9KAfaP2Ti/wBHHAjqEcHMCwTMJ40XxE1LQey4VvePK6defMk5pEHhCE9lN5v635yf/eG63
EL2d4Yv+wBvZjYUsymJh3wgIC8IzPDjW9oiYDrcxL7XniKHI8OcUrJOijs4r/fjSv+4A4ZlFGVMx4wwcoj3OsTkNrTUcjxCesDCi3zMwL3n4dppJdI1nmOmM
QVJXNKVndCjqDb+4cxlKfAdUwWRUZZ9CDMFfHdm8jCn+2BYJhAdTZEG5DKAawAJuSGhANALgl8QKiqcTej1WyYzWRCdXdpYOJOwhpqJfHZ0dfXl0evzm1ctn
G9dGP6xQWxyY+rssLpYXUbJ+ZScJO81TK1ikEOOwwl0chQoJEDKI89D+IAqoLA6LVYskohRYcoGbjTiLffh/7V17U9vIlv9/PkWPyZ2BGdvYxkDihMkkPHay
NUOygezWXYoKwpKxbmTLJdkQhqJqP81+sP0kex7dre6WZBtImJl71X+ALUutfpzuPs/fQY4ATXnsR6DvWLZvG3vFffOmWecUSAPRnt0tHgZoPFITnNlXAcyN
Jrgk+B4oLc5qIpcIikum1bdkI/cP3x4fvP1wuDd3CoheYGF/jzA8yIWPS4iL0S+mksTkqNuUIcxpQjODpyZK8tnKn9QPE5wg/7z5+fPnZiofafZjTb5v3l1u
UewcCQCEIDdmNI5UtpYIHGNelh6O/eMPh+/3X+3+snhAoAWzsV5CZasN7sLNiwLGx0aT9RjIfhpbSxTHn9B59lOgPJnwua7qXFN8sClcDpyE7Vu6r7tvD6Gr
Bx+O9ufPPiwDmCde9VkrXWJVer0wlcpgCngbM0nSeJGUBsfKsg3E9u3vHn88fvPb/tsPx3PbKHdWXibkGxaOSqbkQ8ogZx5vbtQkdLrwUBMZXMFvTYtAU7G1
2d3QcZnEP3vKbkLjjx2DWzr6HngozX5frr+3aN6gU6wgZEH1kzBndmM/WKXovh4QIPmEZI5s0v5DFgB0DOIgMX0jnI30JAos6+tiD6Ty36OApGzeF330oEuE
AvCL4USLeEUzTiMQe4jCNPV1FV/hBxPUDIvWc/nxhdhEtb58tbr6IxkYTHtRH/qBhh55o4QZgosvs+berjXxSmZEkDYvfnaHUGyw3zV6I16EuScuQHtMZM+r
F+XeiT1zXoqX2PAibNeLAkuDwR6vcg9Yg4CfXPWBtDCkKSHnUUtP6AloCcjLiIDJPaSfTpW55lt6YpEXyAgBx4pQJRQqBwiIrJzOPO1tBb6UG9soNxYbEjpd
bUmwlaZHHMM67ssQX21NyPylbXSezFjQVWBDWTxIpp+1FNmFKC62C8YNDVWTtgkda2BA85RZLKRieA5YiayZ95NbC+fDrVOH1cwZyfZWqU1mNpZAqLkhnCSB
G2ae0xxJnYA4B/YM1jL/w1Fa77Qojp/C8pWyAO0V+dCFF0SUhfg7HF7MYwF7GgwE3pt530ATywem3VLtmToNmyB+zDzbEZ2lClKWTn0YVoTBBKL3geeO4gm6
c9VpP6YbcI/yXSFF10cnE4orwNMgq+I3bS+cRfE9ciwIZS0h1z39qREPBmkwtQJa3EgfO/xGz/GLdVzFf7ACxJH/99F54n189Zjxn1vdbdf/Z7PdruI/H6Us
qf9XGtxfCf1iuRhQRIDwMIBgee8gXQNhNh3Hr8lxlVyG3nvjT4FP9FkaKarUFRzFnwAZ02Pi3PMvgroI+4jcTMdFHfYRtOsTfkUduR7UNSBMrKD1TfDVLGcR
hjZjSA0RiGIaTxoJHUmwqbDzEOnqlaMnBj8gGwB0dY27mDcmsAiyYlBVaMhoikMPGC+Mb2MQaslTE3Qx7lSkRaDq4iusX0OET4l3hHNpDPxmoalDrWHgUAIe
LmRR6GPPHMbndAIGieVWVWz8iEJE/rs5o0oaT27oP5rLz/IG89E5WsfpsEF7RSMzjs8BymOlN1vWZQhm1/VbNfbX4gjXZzkDMGnFob4h/obIMYh+mMXvmZaG
zG1UXzV39BXZZ3xdzqczC0SVdw28SyS2D0nkYEkAJw6HW+LDyZxM4dji+1JWPkCfgimr1mCGkzhifQWBy4YjEriI8Jp2hUEKJDttyOCIxpiQxJCIf6alzH/i
BtTQCOBYhBYaz7+Ay8ZXIeBA2Mn1wsGji6Y7NRuuhVbAzk23a9/JYPD561FMrNdOLfJ+vy4FfpH+xgXAlcoWAtykzfogBVLfNfMTn6OCpyHXjCCPaKQBxusx
RzKbboWnfGtEGLvx3+X+HAvJvCgufMNxSnjhWV8zW1qybi0/5y5G+tmpfTyPgFBdkLIEbX/jGMFpyHV9ECP8kiBP9TgJfPf+gv66/iiui4XNtNtWIb30Ttrb
GINuvS0X1MmdpN06B8hCI1TobcJPzXV1KYMgdCN9az8J5UBe6h6zCM4Q0XmyfhRg9MhK1t1reXwWLLneuU+5sa+eBTS2rN/MdrHfjJ6/z9G8UGNu5LlGq3Ga
lIsGdhC2sknMTug8Ik9O2oBVTfw4QYZmdtFlMZ2K3+u2fWI+UrBLFOwTjA42D/NWRqvDXSpevdC7ylg9G3kEhxfIWaEIFCBY+84NuhfvYRYF7hNr7tHvqjmN
3xy9lVEKaznkO+2u5T7nDgXe5zTBMHirUuABwBVr/MDcFrYU3sH8rcPiVlftF+Y64mIw3DO0puTReaE1KF6XRdaUVIfLFfYUi8FWHUSkWVhugj8Ue6kVXJsz
ay/ZDW7nyY3Bj7vrm9HJb1fgwty5xI1mFElwh0LIVznJWraeP8uUDwTlfgsxq7SZC+fdgsF1vlrx/+zp90/itODI/++8i3DMKOmPlf+r1dnI+f9tbmxX8v+j
lAX2f1e2zOiDcy15F+QYj/9T/ID6t3fedJglW4JfzJAdutO8oJ4w4nWy+BS6GxHM23mFOOvXx4GHYQIneKdoiHad20R/xY+ifdochBHs2KurE/Jhm2AmjTba
ECZYL73ASEqEjuloOjFi+GWgzuoJ1N1sNvGFXH16urbWBL55urrq1QWH+HvQhvMi7/5i98FsOAvcB0m5fEew/I7t/XdD/WEfvkldhFYkreozPAc9DimIgcal
wcNwEuKAnsL1tpthweLG+JAiF8DJ7eJjs+Mcmjf4/pf5o27yWXFCzKz93//8r4JRVHyXtaGXnmMTjnmBdyhagwrOntyob7cvcTbxkMszIzRZ0oSkaiLSeilq
+B+BZHXujfLT7+aMjz8SotqtnC+fiiTIQxGluVDUQq8+VbIWFogqizz9VHmIx58q7lDmAUUXn8c2s5LF1Bc6ev7RG+lftLj4P8GFF71DLI/Hw//ptPL5P9sV
/s/jlC+F/0gRtkccWJsOA4yyZXX4FDZhirsN+9d8bJJmHCPf2TsjJDe0vhc1i5TZmiCJ32DdPXyQcil+7A/DyIf9WbMc0m0k89eWN5uX1EMqbRX9PST/gUIF
+Hx7e8cwuLdbmb67FM3RTryjbeGmbTsHhOiAHuZN7O1WqY29FHPxZnnjeafsQCrQp/yKGCZy2MWN/JC9xTCn59Ul0A0V2vcURF01U7eWDGZZTosygs5Sppgh
q34KCUX+9hC6MECKeVLyYZt3mQ3ZImM+OqUApKxY0lGQzc1lnRuy1+mxLRJzK/zlf4WC5783mXydxO+y4CF/t/zv7Xa3U+V/f4yi5l8raL/CO+4+/51t+FfN
/yOU3PyfYHjd6Rclg7vPf7fTaVfz/xilbP4nX1AGXCD/dbfz/l/b7Qr/6VGKlvDG8fQAtVJawGO/Ee8yvGAFpZYGF8aKm6HWhrxYBjNgPqt8l4ofU7+aT2Qq
1OJnDBVrYTx73fZtq98h1QGhUvqvOYUgfynKZEC/kIi8Lvaux94o7IvzgJ3sCdQpSzX/XPrf91WABUidRiVNJekoANvPe7OE+74jtloF+nqFoovtCvsyn70l
yJSEet8I3Ad6Mtxa3K5ZkpaDKqXe8ptMsy5tA/gywxCAX3viHYxMmCJ8Kr9AOc3/pCUs7hz/DkOpgKa4gkxVz4m4duzpW8WHTOgiK5JER3wL0/2vJ87eIcq5
dNxLyaj4RIYqC9KzZsJ484yiOMzB8DmptTsomsaV8kINiLCm/C4DZD9p3orb9csHDOaNNNTgX6rduNci0G+kZeZbg27SeBQowpH0glpomoo1vbGsmkniSYe+
k+Vgb9fFIZmEVnUL1jB3XduwzZzIZJ2E9n6qmycHoelF0eoJza2xLlfZGkRNqRs/0jpdpUunReaa+fqerqHveXp/dU+p39RX0wMt88KC9XQX/ZDUPxQGO8AC
S6WJDUNOJzEbMnTm+athHOmcrOgRiS64IUdI6HVemH01rxx5arqP2keSQpXgTJDrjpFfmc6oGU0EILkDJlZ7jm+i7xFuSXmQxhbpD7fyRqBSaC2ZNoy8hhFm
y81yYJHkipu4++5xDUIgbK4BjRiPTUNT3oizDLaXZfSJXaCvrSzoRXrJlA6wGlL+dt5ouZZGY0rprCMXkcKsoS80I0J2Te1wyR548sKt6UC9c6NSbEzo+63r
zbPm5NCJI6vjBh9D5sgb/HvLGvMd2XL6cqvNmI5jlQRWsTMj5oCnnJgTxf9fRPG5F6XNfpp+cR5zAf+/2W5tOPz/Rme7wn94lPIzRrhdIRQDUtXzb7LvGQ9t
Xp1NESk7DJAT6OGYEJfR4E2sJ1YGVJ7TNbQg46XzwfZgky+hfzZe8getwMsuMej6ymDL7/stvgyLGa60vfZWu8tXcBeES9v97Y3tNl/CWC24FAyC7WCDL8F+
hleebrU3+voKGqypJUHX94h3+znyrnHnwHgxsgVMR5FkFhWyEps7wt+Dhuejq0UP/dz+xlboczg9L2gj6olLL1mVAyBTDHzDyPayvnn3Im8TYXgv/wCdlpfp
pB6ArBBdqx/l4e1frwFDcw0b/6gxC+GjN04baZCEg+dW89lKM4r5qOgJj8AeQuiwr1vZJLeEm+yNl+jwAP/hMtTY7yFuxizyEryQmi0LPGCXAnjvlHLu9AS7
JrKrCNXd63H2Y9zRSgeCp2beUHBdg7g/SxsSbF5WF8+mTDedyWeRxhGw8LpWWaO8RR5mdKecPz4jEs8PZ9D4p3z91qCMjPzpdetWVNEROkBMCHJgQCmyhl7I
B2hAkUYkEMWzVPALyLIJo03xMWVjgT+uma0DenM6ppbKWmEn2k9V7zIfERULr8IjcIRFe6s1SkUAlKDSKGStyd2S0QqtXfL6UH0wKu05Y0+PwKAR/BjlMU4p
WpPzK+sRIVT8m6LePHv2TE0K3shJgPlOhkYzV2PJeOH2UDxWuvZFy3Pi+WwjlFmwRbu5gf/5V+ggpsOuI6pA+PZIHHkDWEDi9zgeSfARlHNgARD9yk7LJYQ7
S48ef26TM2K+5eaxbAadEer1jLzNOgbfmB/cRNfch6h1d5jULKhOzSNFYXEFMjqhJy6S0JeDiG1qSDxnZmyLKbgzZ1L0orabZswVDesVhRz1xHarxVdpAxjK
q22zG4S6Mg0wZFvRpQhCAitEdE5UzjCADKJhyY7i/Q/v6HzyK98Us0HI96pw2efWdddd+vQQelAbv2X0gd3lNd8DeWy1pzLwrBVsYyuDp/5mf8t5mIWt4qf1
u3sYJxkFq7DIumtOBTrpj9z1J14/nF7jguxmd3IeC77DG4cjTy4autxpdrlfcKg0YJnBfoTATNOsnz8Dlz9IQORIhVlT6288SrjTaLdJ3QA56sxYbxbd0YK9
IruJTxeMMvIE5nYeBEnaSAJ/1gdhZhRzi/k7D9AP+PYfer3zAMYokF+8wVSvbN3Thi/1gPjOVhum8VvWUsJZ/ty5FfrN9zYofwX0I3dzRkiLKr6tHAP+2kXJ
f1/S3uOWBfLf9mbbtf90tir/v8cpf5DVZjfywtE7b2yBCZiv0r+bT6l8zsXPqF8fbh2yEgoUP2jdYnlKZhBB9TyaU3FlxjNW4zGH3tGb/15siZp41xjXne7S
LzN0wrQf8WM/zpuuVCfqdzVlFeE0LERlIFQX4BWmCDTm+altBkF/UcoCghrIVPhsKCMPUYyCP0uCS5Be0ZHwjPSdWONVPAOhwI8VfAKnGVDmM8xJ7FrQFHRa
XXjEtSh8B9la/DoCsfUSszZ6Y4V/SIMrQK4exvEnSgKCWY/FFaNGYEKDCG5OLTiGRSa6EqsRTYE2GRUaiu5tA1rWxHMfI803jEJmmmjqQuWDoZ+zJDIEgpAE
Aev4Eeq7CRLz9B3S0kGcHKBmeXVNMBRdDCTRSGZsIEBP4URDbKjKcPKuGbqRbvd43qbxhOaGsDyGYX8ok8B7Ed5yLS6IPmYp66hPips+z85UZGnCwBSdujBn
a8ouqqWnrp8y2ytTzjDo21o2Xm8R5ChEeaIfTKZ5qCOFxwrEhXARTbGPwCQ2KKunKlM4rEThfkDAk5zG2wZbFQ5+Wwk2nZH4hW7EGKIk7gdp2gzGl83Dt3v7
H/cP/1N8iyBu8AswuLThZolgpO3thbEP0jt3bvAvarRNVpugZTNwu1vDqmhSECa3sTTyMkuLGSNq34B2iTaLjdLETOp9IUN+VBTRamZGOGmdvjTD8cXLl0wB
MkQpq2ogm7SqAtXWYNfJNvgfWZpQlm26ldddOOZHjLvrvMw48VyZ9VJbtfShSZ2VZgqyEqg7XOOZZevc/JyhjbcVBD1Du8AFC6QlO7T1NWHPyc6N9dU0iASE
kuOj3cM9y1YNy0mJtW7JPsjWm412HkRZnqO78/BlqE5C8LJnIrro4Y0oVKeNE5gj3B5b9fYgWfuYfdtKgtHaKd1MFeZQQpxI7CLcEDf0D9cfKRqXARF5sEO6
Kscq14JbveGgrkqB4fQnx2yqH5/kIsRNML2FmY5KYfWM1tDCu/1ujNbX5ze4tG5RsXNjLKHFuRuz/k7cl6wVRyPmQC0KjdQFAAI2H+7YEIuqXcpQXdwCxmtC
G2ux9bkoTVEeRPIe9GRQFJ5MwWgyvV5msB8YlmK/nrfkSObG7scpHBFP2sz2eZ8kejQyEekktjCXSpvnQAhgKcJxyRu5XSs7ljtYq6lSJWYV/CYcK3bhLZZl
u/COedbuggdyaBauDZya7djByVJt0/x9LOPogGO9P79yXthSnszOJnONwGXHkF6GBvEnwHB8SFH6H+DEGwT3/RWUQAv0P+2Nlov/sIEpYSv9zyOU5fAflLCq
xdRD7dR3h2BJYmgwBn7YONluXQ5PJXsWXTCbA9yUi2lAvGbRiVTGOmwVnEZ4HXm32k/dVncZlOKNe3nOHRoYjnqnmOMwt7HQYY40JsT9U/aA77xJnD6XKQTI
5kj54tUBhvKHSoXFu6JuRdZlCyVB+SrqCyb8AlpmNRuNUBQSOwCmZNtCEz5BG2YeL4y82nIITlDJyYr/bLPbGWgAuKzDr0n8jLMu6B5kjmV/+S33T1XU/p/O
+iixf5U4wHvEf2FKoCr+5xGKO/9fww604PzvdLrbufiv7Sr+51HKF8N/sNXeMhAEEzTpNB7vpB49CfpBeBn4NQyjWKAOP2KyvJ9CHEWUWTo/LIJuWagJH3gh
eiDsqPu/+059IqUmLZ7AD9D09MdwQzYn8xD3f9nVlzJ/kTJ+yLQrFzGpX2cXQ0Q+qv09nn2fBMp9n07s2lLBAht3ByvghhkC3MssFQ0m4+oPEfvWb4pfUNmJ
jiksyifXwrvAOVDphlCcR60DDC2wOAiG27TzHZ79nfJPSb5K5R6QsQieGARXQCZAGH6qXYTkKFFG81Dm0QJqGnqU84lDHmYTwc4bHk479K4uAiCOSMzYNe4q
+J5gUxLMS948u/3LcW8G7eQYOSSXs6MgwFFxQqrO3MiWist7vKLOf8p68ZVQIO7B/8HHiv97jGLP/9fxAlrA/8FPrv/PxvZWp+L/HqN8ff7vmyyRG6XFoTRo
dvjtL/GVsunX1bnLZ6IyBlISzqJYXGQh+Z1H+7vHb94eHiEaKLyBbcsa4qlmvIMzespcbZM4pPQXyqRfI+dmYA/8oB9SbqVrzkcJdDKmRKboU4BtUzk70L7e
FIexuIynAaVyEIEfTuMk9CIxQSxmuuZFmCh8OhypLHHwrtehL7NvUuTjhyPhx1EE3EYTLREXmA0Cs3Ga/JXxNLApMqHp0LtEUwX6kGPrVtpN8V/AvVF6UqwA
hrFOHyJiNFBDdckZRYDjJoxndl2m1xlvAC5mehVnUzIkBgF5KFQ28ZOUPQUDAbm6i1hmrZT2lYSCPofAZmb58bjnki2TnaMayfeW8ideU6oY8ufwQvRfmLJz
D6KxyhYngWwzvT/yqQ3I5J3jqPLAkEODeu2pTjjoEgcOFo0P+lBEWYLOHHG8EtKBoQ5cHHpwYUuBRQrweyQJhD1BPMo3OIijMCZdHRER8oFQwwD4JGMwdjln
pC/C8SXURcPAdEFpQTBJg8wvexxEwQXIJnWa3/TVZFIXe2Hap/Ssv4GkFIwvgqQujsKLMSLq0bqWWVC52WOeH4Fe2xOjDXQnMKrJFGNXePVhMxvpkFhao1E6
T6vOgohzlwReGo+NGt+OOXsNcpKw3qcKWBqEuvNRSHFDQsYbaUaaavrw/leceCY2ID9k2DG3JuV9lIOBzaP1cQ6rEN49Av7UXBvHUsChG70B9CTErBUU9x5M
qYNJQIIhsPc+72lX5pJJqZGLSUdKtaXbiZJ6YUcZQlsi3lH2Yj8W6tGmIIGDYigYKy9l37KcaAE7yUzCJkpxRAoiRs/J84c2qRADq4MGLSSeTqKJY1qdTF2U
8tN+ntoyggevSetMBAOUHrBIRe3CgH9cbLzd8KaBfaBKz2fXOO6ctVRKDzigQ/S6Q4oBWS3CdJweb26UVCkbadUCGo0rFGMGHopptF9RT6BXuMGk2EfsjUeD
a7iH0RwoinI3TdjSsPm8dV9gBzk5KGV78tRwG6IZe9+TnMhprNHfB6Q32GID2cDwM0Z8zSj+C92S0sVk8x4p1ovKqOY3L7qCwayLyTBMh3Qupn1yk/R8VJNg
OhvKaonUrbJvQ1sQLZPzPdOCoF5hxIMnJ9oYCGj9yLuWd9KOqyVeGDyYAehnPwl4yarstp5IRzgduOVJB0kPE9r4F5RYSCa9orGcmUT1XrZHnySfgmCC8xMm
msLhFXBoXlPeYwz6ILmbV2ZuItXAns6xURG3QZqjhyF6/gkRHqTTw+a9XmgmJ/zCSpojPD8ELNWUGDuL9cAFzZ/gaFamLNjCUSOAW8uSuA7Qd4V52e5Ywyj5
P3aWkOiVOXcJhdjJHhHyS1PhbjreNgXOU/ebY9lE93WOb4/rS/VilvMT0X3Pu3rp2nkzkaDv+LnEZ+RFFBZ4bTCOOz5W5NNhNEc6xUWNjpveM1o60WruDYUu
XCWtUZk4zJJP8zGzYRbWHcRW85F/Jr+OZYuS/yMPVub060QALcR/2MrJ/50q/udxipTwKcXmjVAAXhYInBWSEs3Sj//uffKSqffxyBunNlwcboXrF3F8ERlR
Igvx4t4eHr/aPf64/9urN79K/LW9/aPd92/e4YZuILLJjygfzI+IqTVNQBOJvYbyCCMqKBsGUDxLr1feNSfbxKDMYNxnhws8mSh4gMJsQTZMVIwIVjcMgwRt
RdcqpgQ5Tk8y5PAidKGXSUVwnHbyY8cWrdk5Zn0E3q8WgXw0rhFrQ3LROSlNDOAHYn5UgPNJrdtq1eqitsn/tvjfNv97Cv+oJh2lXEuvvAnUcLtWpq3pZfPP
ehv1w2svxbh0EL1h6FfVHFDkglTtyIhoZsEou0bG1dAYJlKrco7jLsVQYO/GgX/GHN00GEE7EeHj7G8pPWLZCDQjbWmOcrTyjSBG/d8SbzJUrZJNzKhItnVB
PULMkqinKY4vId+Lx1+uOlxAMMZXwTneUtPNnQIvPEVsAhmLT/gntXQ2GnnJ9ccITVYfwxFmEqk/pLG3rAkrZYVh8/qVdniiuRwS+l1hzxEtRR6akYd5PIOC
BDY3QAVI+k1FzMrSoxlOAklxkkwOGzLxt4FXMg+zHKoZQO8QscP2C+4W+u/PzdRZHvnwrCB0gGrIu0ObOTGzNJAOn8JCOi2KWOKbsTc0WjIniEYIQicqFWmI
ULHo2x7IOe9jzDDk8u/5xIOca3BLZhpcDNkm6zblHmB6Z1NL+MmDhuUyueX5uldYjfuegmR8YlF29nu93U7QvvTbgcxGX+Dtx1gNHhdHQXIZ9t1cPUs0ZJKE
l17/+uFNeccViXeUoOMe88H6oy8wI1zRci1wk+PqlIWotJnGvSc3FlORz+sk7the5/F883cxv3A/T9CeG8AhcxYZl1yxu6sjGspX5K9Kj8IZhb2peNJuIofD
2j6txRrHxGCow6OpdY5OfaWqyXmbTi5jIm/EmZs8bl5KnsIj419AnvqrFSX/0a7+J7L/b1b2/0cp9vz/Ifb/ja18/Mf2RquS/x+jPKr9n3i+Avs/mV8tkTGU
LnEoXcuAh1SZ+8uEHKq90vfnXmhy2qzvL9euP9UK5runk3phMQcs4fhhEvTJqtPH4HBGGVBuGBj5SSqApvgwkc4TkQfTORS+d53Wjdoyh4q+hNOoixFiYCYh
wSwGUXDpod4GTeFBChUi6zYOMNnnKEag4oFRG6J81K3wTuUNiv6tMXpjkB04naBdCu+jOlApAXTm+dDOeGzUBzQ37ocBXUaTxlQaQMNE9acfgwiKBnBTjrPY
KXv08om/Vebznwz6UflQ2YYnEQeB7IMxeqQcD03Bwhh0A9QO+DzoW0K+G2MrnAjI6zIgcw0uRPyPQbFGhTiT5IDBNli26KQGjvco6EOlYTpiKJVQ3wLvHqP7
gDWGAUvE8dVS46MdNsiAhHZJ3LHQ6cLYWcRkFkXKuJ+5X7B3BhpOjQopabogRDSc+Fh7g6RBAPsPsPZoc8e3MjmgeZx1WU3dGKM618SV8vvlc9qQPiWPls+I
JZqk0GDToL7MMLxRnafIXIlg4iGJijSKp7Kb0mb7j/hTIOicB/HmCmQGtCCH1iSEKRMGO5vgQ7LD5JeBooVEFkHrP7SU3F0+jeOrlHQYS7X5P2boCwLHRJ3p
1otS8o/Rtne2KV+ROTn0gyvYCnpzgc3zOoH7IJtr3JjE0Q3I7dltArk30S4y5jmG6Yxn/WHhIPxpTUsK2LnJJzkwf1/+HQv4v/bGZh7/u9Ot+L/HKLb9hzFX
NI+niEPaUBzGS8bR4C6C1ojmOsoSP/yw/kPzZprWQYq4ZQsEnrbaRAALM0CwUAX9Q7CkafYdEXcJSby2ckCllrEBfViio8JfGGkcfnh9sH2waT7C+vaVg72D
1v4r5weG24Uft/Z291rGj4Q9Xltpv0LwceM6I5DXVrZ3EYLc+IFxyGsr+wf72/sbxg+ERg7XEY58177OmOTY5v3untm03z165mBz9+nWa+N6+gmtOCtbr189
3XtqtiocU0Ubr1/tb+3rH27VB2QRDySSeDbM2i50UnPhxdF+pAHG6YuGGOcZle2Bqw94HM7CuOzxWdjAn4kXxe/Zl1One7fa0jKJZhchtQjuuYXWTcN0gPY6
Jurnf/ROW5WqVKUqValKVapSlapUpSpVqUpVqlKVqlSlKlWpSlWqUpWqVKUqValKVapSlapUpSpftvw/DnWBRwAYAQA=
B64
rm -f src/components/Hero.tsx src/components/BidForm.tsx src/components/Rail.tsx
printf 'Restyled:\n'
printf '  white background, soft peach cards, no hard outlines\n'
printf '  pill inputs and buttons\n'
printf '  Plus Jakarta Sans throughout (one family)\n'
printf '  rank badges, favicon tiles, meta line on rows\n'
printf '  centred stats pill in the header\n\n'
# Mobile responsiveness fixes.
# Keep the browser viewport at device width and don't switch the bid form to
# desktop columns until tablet width. This prevents the 3-column form from
# being squeezed on phones / narrow tablets.
python3 - <<'PYFIX'
from pathlib import Path

# layout.tsx — explicit mobile viewport metadata.
p = Path("src/app/layout.tsx")
s = p.read_text()
s = s.replace(
    'import type { Metadata } from "next";\n',
    'import type { Metadata, Viewport } from "next";\n',
    1,
)
marker = 'export const metadata: Metadata = {\n'
viewport = '''export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

'''
if 'export const viewport: Viewport' not in s:
    s = s.replace(marker, viewport + marker, 1)
p.write_text(s)

# ClaimPanel.tsx — stack the form on narrow screens; only use the desktop
# three-column layout at md (768px). Also make the hero reliably stack.
p = Path("src/components/ClaimPanel.tsx")
s = p.read_text()
s = s.replace(
    'className="flex flex-wrap items-center justify-center gap-x-4 gap-y-3"',
    'className="flex flex-col items-center justify-center gap-3 sm:flex-row sm:flex-wrap sm:gap-x-4 sm:gap-y-3"',
    1,
)
s = s.replace(
    'className="grid gap-2.5 sm:grid-cols-[1fr_minmax(0,12rem)_auto]"',
    'className="grid min-w-0 gap-2.5 md:grid-cols-[minmax(0,1fr)_minmax(0,12rem)_auto]"',
    1,
)
s = s.replace(
    'className="pill w-full bg-pop px-9 py-[0.95rem] text-[16px] font-bold text-paper transition hover:bg-[#d9542f] disabled:cursor-not-allowed disabled:bg-popsoft disabled:text-pop/50 sm:w-auto"',
    'className="pill w-full min-w-0 bg-pop px-9 py-[0.95rem] text-[16px] font-bold text-paper transition hover:bg-[#d9542f] disabled:cursor-not-allowed disabled:bg-popsoft disabled:text-pop/50 md:w-auto"',
    1,
)
p.write_text(s)

# Masthead — prevent narrow screens from forcing the nav wider.
p = Path("src/components/Masthead.tsx")
s = p.read_text()
s = s.replace(
    'className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-5 sm:px-6"',
    'className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-4 sm:gap-4 sm:px-6 sm:py-5"',
    1,
)
s = s.replace(
    'className="flex items-center gap-5 text-[15px] font-medium text-mute sm:gap-7"',
    'className="flex shrink-0 items-center gap-4 text-[14px] font-medium text-mute sm:gap-7 sm:text-[15px]"',
    1,
)
p.write_text(s)

# Main page — tighter mobile padding and min-width guards.
p = Path("src/app/page.tsx")
s = p.read_text()
s = s.replace(
    'className="mx-auto max-w-5xl px-4 py-10 sm:px-5 sm:py-14"',
    'className="mx-auto max-w-5xl min-w-0 px-4 py-8 sm:px-5 sm:py-14"',
    1,
)
s = s.replace(
    'className="mx-auto max-w-5xl px-4 sm:px-5"',
    'className="mx-auto max-w-5xl min-w-0 px-4 sm:px-5"',
    1,
)
p.write_text(s)

# Global guard against accidental horizontal overflow.
p = Path("src/app/globals.css")
s = p.read_text()
old = '''  body {
    background: var(--paper);
    color: var(--ink);
    font-family: var(--font-body), system-ui, sans-serif;
    -webkit-font-smoothing: antialiased;
  }'''
new = '''  body {
    background: var(--paper);
    color: var(--ink);
    font-family: var(--font-body), system-ui, sans-serif;
    -webkit-font-smoothing: antialiased;
    overflow-x: hidden;
  }'''
if old in s and 'overflow-x: hidden;' not in s:
    s = s.replace(old, new, 1)
p.write_text(s)

# Final mobile hardening: prevent any child from creating page-level horizontal
# overflow and disable pinch/page zoom on touch browsers.
p = Path("src/app/globals.css")
s = p.read_text()
mobile_guard = r"""

@layer base {
  html, body {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: hidden;
  }

  *, *::before, *::after {
    box-sizing: border-box;
  }

  main, section, header, footer, nav, ol, ul, li, form, article, aside, div {
    min-width: 0;
    max-width: 100%;
  }

  img, svg, video, canvas {
    max-width: 100%;
  }

  input, select, textarea, button {
    max-width: 100%;
  }
}

@media (max-width: 767px) {
  .card {
    width: 100%;
    max-width: 100%;
    overflow: hidden;
  }

  nav[aria-label=\"Categories\"] {
    width: 100%;
    max-width: 100%;
    overflow-x: auto;
    overscroll-behavior-x: contain;
  }
}
"""
if 'Final mobile hardening:' not in s:
    s += mobile_guard
p.write_text(s)
PYFIX

printf 'Mobile responsiveness fixes applied.\n'


printf 'Type-checking...\n'
npx tsc --noEmit || { printf '\nUndo: rm -rf src && cp -R .backup-%s/src . && cp .backup-%s/tailwind.config.ts .\n' "$STAMP" "$STAMP"; exit 1; }
printf 'Clean.\n\n'
git add -A
git commit -m "restyle to match reference: soft cards, pill inputs, single sans" || printf 'Nothing to commit.\n'
git pull --rebase --autostash
git push
printf '\nPushed.\n\n'

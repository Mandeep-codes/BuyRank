"use client";

/* eslint-disable @next/next/no-img-element */

import { timeAgo } from "@/lib/format";
import { useActivity, type BidItem, type ClickItem } from "./activityStore";

/**
 * The left rail from the reference layout: one row per outbound click,
 * newest on top. Every row here is a real redirect through /r/[id] — the
 * feed is the receipts for the click counts bidders are paying for.
 */
export function LiveTraffic({
  initialClicks,
  initialBids,
}: {
  initialClicks: ClickItem[];
  initialBids: BidItem[];
}) {
  const { clicks } = useActivity({ items: initialBids, clicks: initialClicks });

  return (
    <section aria-label="Live traffic">
      <h2 className="flex items-center gap-2 text-[13px] font-bold uppercase tracking-[0.1em] text-mute">
        <span className="blink h-1.5 w-1.5 rounded-full bg-pop" aria-hidden />
        Live traffic
      </h2>

      {clicks.length === 0 ? (
        <p className="card mt-4 px-4 py-5 text-[13px] leading-relaxed text-mute">
          This feed is measured, not simulated — the first outbound click on
          any listing lands here.
        </p>
      ) : (
        <ul className="mt-4">
          {clicks.slice(0, 6).map((click, i) => (
            <li
              key={click.id}
              className={`flex items-center gap-3 border-b border-rule py-3 last:border-b-0 ${
                i === 0 ? "feed-enter" : ""
              }`}
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-rule bg-white">
                {click.faviconUrl ? (
                  <img
                    src={click.faviconUrl}
                    alt=""
                    width={20}
                    height={20}
                    loading="lazy"
                  />
                ) : (
                  <span className="text-[13px] font-bold text-mute">
                    {click.displayName.charAt(0).toUpperCase()}
                  </span>
                )}
              </span>
              <span className="min-w-0">
                <span className="block truncate text-[14px] font-bold leading-tight">
                  {click.displayName}
                </span>
                <span className="block text-[12px] text-mute">
                  got a click {timeAgo(click.createdAt)}
                </span>
              </span>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

"use client";

import { formatUsd, timeAgo } from "@/lib/format";
import { useActivity, type BidItem, type ClickItem } from "./activityStore";

/** The right rail: newest settled bids. Polling is shared via activityStore. */
export function ActivityStrip({
  initial,
  initialClicks = [],
}: {
  initial: BidItem[];
  initialClicks?: ClickItem[];
}) {
  const { items } = useActivity({ items: initial, clicks: initialClicks });

  return (
    <aside aria-label="Recent bids">
      <h2 className="text-[13px] font-bold uppercase tracking-[0.1em] text-mute">
        Recent bids
      </h2>

      {items.length === 0 ? (
        <p className="mt-4 text-sm text-mute">
          Nothing yet. The first bid shows up here.
        </p>
      ) : (
        <ul className="mt-4 space-y-2">
          {items.slice(0, 7).map((item) => (
            <li key={item.id} className="card flex items-center gap-3 px-3.5 py-2.5">
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[14px] font-semibold leading-tight">
                  {item.displayName}
                </span>
                <span className="block text-[12px] text-mute">
                  {timeAgo(item.createdAt)}
                </span>
              </span>
              <span className="tnum shrink-0 text-[15px] font-bold text-pop">
                {formatUsd(item.amountCents)}
              </span>
            </li>
          ))}
        </ul>
      )}
    </aside>
  );
}

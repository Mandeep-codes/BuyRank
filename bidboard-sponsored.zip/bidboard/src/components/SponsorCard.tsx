"use client";

/* eslint-disable @next/next/no-img-element */

import { useEffect, useState } from "react";
import type { SponsorState } from "@/lib/queries";

/** "6h 6m left" — under an hour it switches to minutes only. */
function timeLeft(endsAt: string, now: number): string {
  const ms = new Date(endsAt).getTime() - now;
  if (ms <= 0) return "ending now";
  const minutes = Math.floor(ms / 60_000);
  if (minutes < 60) return `${minutes}m left`;
  const hours = Math.floor(minutes / 60);
  if (hours < 48) return `${hours}h ${minutes % 60}m left`;
  return `${Math.floor(hours / 24)}d ${hours % 24}h left`;
}

/**
 * The rented placement, top of the left rail. Both chips are measured:
 * clicks are counted from this rental's own start (not lifetime), and the
 * countdown runs off the slot's real end time. When nothing is rented the
 * card simply doesn't render — the rent panel on the other rail is the
 * empty state.
 */
export function SponsorCard({ initial }: { initial: SponsorState }) {
  const [state, setState] = useState(initial);
  const [now, setNow] = useState(() => Date.now());

  // The countdown ticks locally; the state itself refreshes on a slow poll.
  useEffect(() => {
    const tick = setInterval(() => setNow(Date.now()), 30_000);
    const refresh = setInterval(async () => {
      try {
        const res = await fetch("/api/sponsor");
        if (res.ok) setState((await res.json()) as SponsorState);
      } catch {
        // Keep showing the last known state.
      }
    }, 60_000);
    return () => {
      clearInterval(tick);
      clearInterval(refresh);
    };
  }, []);

  const current = state.current;
  if (!current || new Date(current.endsAt).getTime() <= now) return null;

  return (
    <section aria-label="Sponsored listing" className="mb-8">
      <a
        href={`/r/${current.entryId}`}
        target="_blank"
        rel="noopener nofollow sponsored"
        className="card block rounded-2xl border-pop/40 px-5 py-5 text-center transition hover:border-pop"
      >
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-pop">
          Sponsored
        </p>

        <span className="mx-auto mt-4 flex h-14 w-14 items-center justify-center overflow-hidden rounded-2xl border border-rule bg-white shadow-sm">
          {current.faviconUrl ? (
            <img src={current.faviconUrl} alt="" width={30} height={30} />
          ) : (
            <span className="text-xl font-extrabold text-mute">
              {current.displayName.charAt(0).toUpperCase()}
            </span>
          )}
        </span>

        <p className="mt-3 text-[16px] font-extrabold tracking-tight">
          {current.displayName}
        </p>
        {current.description ? (
          <p className="mt-1.5 line-clamp-2 text-[13px] leading-snug text-mute">
            {current.description}
          </p>
        ) : null}

        <p className="mt-4 flex flex-wrap items-center justify-center gap-2">
          <span className="tnum rounded-lg bg-popsoft px-2.5 py-1 text-[12px] font-bold text-pop">
            {current.windowClicks.toLocaleString("en-US")}{" "}
            {current.windowClicks === 1 ? "click" : "clicks"}
          </span>
          <span className="tnum rounded-lg bg-popsoft px-2.5 py-1 text-[12px] font-bold text-pop">
            {timeLeft(current.endsAt, now)}
          </span>
        </p>
      </a>
      <p className="mt-2 text-center text-[11px] text-mute">
        Clicks counted since this rental started.
      </p>
    </section>
  );
}

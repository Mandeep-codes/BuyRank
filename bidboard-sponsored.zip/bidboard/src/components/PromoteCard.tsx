"use client";

import { useState } from "react";
import { SPONSOR_MAX_DAYS, SPONSOR_PRICE_CENTS_PER_DAY } from "@/lib/config";
import { formatUsd } from "@/lib/format";

/**
 * The dashed "Promote your project here" card from the reference. Price is
 * days × the flat day rate; the server re-derives it, so the number here is
 * a preview, not an authority. If a rental is already running, the new one
 * queues behind it and this card says when it starts.
 */
export function PromoteCard({
  enabled,
  nextOpenAt,
}: {
  enabled: boolean;
  nextOpenAt: string;
}) {
  const [open, setOpen] = useState(false);
  const [url, setUrl] = useState("");
  const [days, setDays] = useState(1);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const queueMs = new Date(nextOpenAt).getTime() - Date.now();
  const queuedHours = Math.ceil(queueMs / 3_600_000);

  async function rent(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setPending(true);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind: "sponsor", submission: url, days }),
      });
      const data = (await res.json()) as { checkoutUrl?: string; error?: string };
      if (!res.ok || !data.checkoutUrl) {
        setError(data.error ?? "Couldn't start checkout.");
        return;
      }
      window.location.href = data.checkoutUrl;
    } catch {
      setError("Couldn't start checkout. Try again in a moment.");
    } finally {
      setPending(false);
    }
  }

  return (
    <section
      aria-label="Rent the sponsored spot"
      className="mb-8 rounded-2xl border border-dashed border-pop/50 bg-wash px-5 py-5 text-center"
    >
      <span className="mx-auto flex h-11 w-11 items-center justify-center rounded-xl bg-popsoft text-lg font-extrabold text-pop shadow-sm">
        $
      </span>
      <p className="mt-3 text-[15px] font-extrabold tracking-tight">
        Promote your project here
      </p>
      <p className="mt-1 text-[13px] leading-snug text-mute">
        The sponsored card, rented by the day for{" "}
        <span className="font-bold text-ink">
          {formatUsd(SPONSOR_PRICE_CENTS_PER_DAY)} / day
        </span>
        . Clicks on it are counted and shown on the card.
      </p>

      {!open ? (
        <>
          <button
            type="button"
            onClick={() => setOpen(true)}
            disabled={!enabled}
            className="pill w-full bg-pop px-4 py-2.5 text-[14px] font-bold text-paper transition hover:bg-[#d9542f] disabled:cursor-not-allowed disabled:bg-popsoft disabled:text-pop/50 mt-4"
          >
            {enabled ? "Rent this spot" : "Opening soon"}
          </button>
          {queuedHours > 0 ? (
            <p className="tnum mt-2 text-[11px] text-mute">
              Currently rented — next opening in ~{queuedHours}h. New rentals
              queue behind it.
            </p>
          ) : null}
        </>
      ) : (
        <form onSubmit={rent} className="mt-4 text-left">
          <input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="yourproject.com"
            inputMode="url"
            autoComplete="url"
            required
            className="field w-full text-[14px]"
          />
          <div className="mt-2.5 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                aria-label="Fewer days"
                onClick={() => setDays((d) => Math.max(1, d - 1))}
                className="step h-8 w-8 text-[15px]"
              >
                &minus;
              </button>
              <span className="tnum min-w-14 text-center text-[13px] font-bold">
                {days} {days === 1 ? "day" : "days"}
              </span>
              <button
                type="button"
                aria-label="More days"
                onClick={() => setDays((d) => Math.min(SPONSOR_MAX_DAYS, d + 1))}
                className="step h-8 w-8 text-[15px]"
              >
                +
              </button>
            </div>
            <span className="tnum text-[15px] font-extrabold text-pop">
              {formatUsd(days * SPONSOR_PRICE_CENTS_PER_DAY)}
            </span>
          </div>
          <button
            type="submit"
            disabled={pending}
            className="pill w-full bg-pop px-4 py-2.5 text-[14px] font-bold text-paper transition hover:bg-[#d9542f] disabled:cursor-not-allowed disabled:bg-popsoft disabled:text-pop/50 mt-3"
          >
            {pending ? "Starting checkout…" : "Continue to payment"}
          </button>
          {error ? (
            <p className="mt-2 text-[12px] font-semibold text-pop">{error}</p>
          ) : null}
        </form>
      )}
    </section>
  );
}

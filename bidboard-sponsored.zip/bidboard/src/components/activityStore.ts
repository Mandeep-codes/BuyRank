"use client";

import { useSyncExternalStore } from "react";

export type BidItem = {
  id: string;
  displayName: string;
  amountCents: number;
  createdAt: string;
  entryId: string;
};

export type ClickItem = {
  id: string;
  displayName: string;
  faviconUrl: string | null;
  createdAt: string;
};

type Snapshot = { items: BidItem[]; clicks: ClickItem[] };

/**
 * One poll for both rails. However many feed components are mounted, the page
 * makes a single /api/activity request per window — the first subscriber
 * starts the timer, the last one out stops it.
 */
const POLL_MS = 15_000;

let snapshot: Snapshot = { items: [], clicks: [] };
const listeners = new Set<() => void>();
let timer: ReturnType<typeof setInterval> | null = null;
let inFlight = false;

async function poll() {
  if (inFlight) return;
  inFlight = true;
  try {
    const res = await fetch("/api/activity");
    if (!res.ok) return;
    const data = (await res.json()) as Partial<Snapshot>;
    snapshot = {
      items: Array.isArray(data.items) ? data.items : snapshot.items,
      clicks: Array.isArray(data.clicks) ? data.clicks : snapshot.clicks,
    };
    listeners.forEach((l) => l());
  } catch {
    // A dropped poll isn't worth surfacing; the next one catches up.
  } finally {
    inFlight = false;
  }
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  if (listeners.size === 1) {
    poll();
    timer = setInterval(poll, POLL_MS);
  }
  return () => {
    listeners.delete(listener);
    if (listeners.size === 0 && timer) {
      clearInterval(timer);
      timer = null;
    }
  };
}

export function useActivity(initial: Snapshot): Snapshot {
  return useSyncExternalStore(
    subscribe,
    () =>
      snapshot.items.length > 0 || snapshot.clicks.length > 0
        ? snapshot
        : initial,
    () => initial,
  );
}

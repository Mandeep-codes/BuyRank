#!/bin/sh
set -u
[ -f package.json ] || { printf 'Wrong folder.\n'; exit 1; }

printf '\nOpen Supabase > your project > Connect.\n'
printf 'Copy the two pooler strings and paste them below.\n'
printf 'Replace [YOUR-PASSWORD] with your real password first.\n\n'
printf 'Transaction pooler (port 6543)\n> '
read -r TXN
printf '\nSession pooler (port 5432)\n> '
read -r SESS
printf '\n'

clean() { printf '%s' "$1" | tr -d '[:space:]' | sed 's/[?&]channel_binding=require//'; }
TXN=$(clean "$TXN"); SESS=$(clean "$SESS")

[ -n "$TXN" ] || { printf 'Nothing given. Aborted.\n'; exit 1; }
[ -n "$SESS" ] || SESS="$TXN"

case "$TXN" in
  *YOUR-PASSWORD*|*\[*) printf 'Still has a [PLACEHOLDER]. Put your real password in.\n'; exit 1 ;;
  *@host/*|*user:pass*) printf 'That is the example placeholder, not your real string.\n'; exit 1 ;;
esac
case "$TXN" in
  *db.*.supabase.co*) printf 'Warning: that is the DIRECT host (IPv6 only).\n'
                      printf 'Use the one containing "pooler.supabase.com".\n\n' ;;
esac

[ -f .env.local ] && cp .env.local ".env.local.backup.$(date +%s)"
TOKEN=$(openssl rand -hex 24 2>/dev/null || echo "change-me-$(date +%s)")

cat > .env.local <<ENVEOF
DATABASE_URL="$TXN"
DIRECT_DATABASE_URL="$SESS"

NEXT_PUBLIC_SITE_URL="http://localhost:3000"
NEXT_PUBLIC_SITE_NAME="bidboard"

DODO_ENVIRONMENT="test_mode"
DODO_PAYMENTS_API_KEY=""
DODO_PRODUCT_ID=""
DODO_WEBHOOK_SECRET=""

ADMIN_TOKEN="$TOKEN"
ENVEOF

printf '.env.local written.\n\n--- checking connection ---\n'
npm run db:check --silent || { printf '\nCould not connect. Fix the string and rerun.\n'; exit 1; }
printf '\n--- creating tables ---\n'
npm run db:push || { printf '\ndb:push failed.\n'; exit 1; }
printf '\n--- verifying ---\n'
npm run db:check --silent
printf '\nDone. Now run:  npm run dev\n\n'
